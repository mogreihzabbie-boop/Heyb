import 'dotenv/config';
import express from 'express';
import cookieParser from 'cookie-parser';
import Database from 'better-sqlite3';
import jwt from 'jsonwebtoken';
import crypto from 'node:crypto';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import multer from 'multer';
import { v4 as uuidv4 } from 'uuid';
import { OAuth2Client } from 'google-auth-library';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = Number(process.env.PORT || 3000);
const NODE_ENV = process.env.NODE_ENV || 'development';
const DATA_DIR = process.env.DATA_DIR || __dirname;
fs.mkdirSync(DATA_DIR, { recursive: true });
const JWT_SECRET = process.env.JWT_SECRET || (NODE_ENV === 'development' ? 'dev-only-change-me' : '');
if (!JWT_SECRET) throw new Error('JWT_SECRET is required in production.');

const db = new Database(path.join(DATA_DIR, 'heybiage.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT UNIQUE,
  email TEXT UNIQUE,
  google_sub TEXT UNIQUE,
  role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('user','admin')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS otp_codes (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  phone TEXT NOT NULL,
  code_hash TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  used INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_otp_phone ON otp_codes(phone, used, expires_at);
CREATE TABLE IF NOT EXISTS listings (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  title TEXT NOT NULL,
  price INTEGER NOT NULL CHECK(price > 0),
  category TEXT NOT NULL,
  condition TEXT NOT NULL,
  location TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  icon TEXT NOT NULL DEFAULT '📦',
  status TEXT NOT NULL DEFAULT 'pending_payment' CHECK(status IN ('pending_payment','paid','approved','rejected')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  paid_at TEXT,
  reviewed_at TEXT,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_listings_status ON listings(status, created_at DESC);
CREATE TABLE IF NOT EXISTS listing_photos (
  id TEXT PRIMARY KEY,
  listing_id TEXT NOT NULL,
  file_path TEXT NOT NULL,
  original_name TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  FOREIGN KEY(listing_id) REFERENCES listings(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS payments (
  id TEXT PRIMARY KEY,
  listing_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  amount INTEGER NOT NULL,
  provider TEXT NOT NULL DEFAULT 'mpesa',
  status TEXT NOT NULL DEFAULT 'initiated' CHECK(status IN ('initiated','pending','paid','failed','cancelled')),
  merchant_request_id TEXT,
  checkout_request_id TEXT UNIQUE,
  receipt TEXT UNIQUE,
  phone TEXT NOT NULL,
  result_code TEXT,
  result_description TEXT,
  raw_callback TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(listing_id) REFERENCES listings(id) ON DELETE CASCADE,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_payments_listing ON payments(listing_id);
`);

const uploadsDir = path.join(DATA_DIR, 'uploads');
fs.mkdirSync(uploadsDir, { recursive: true });
const storage = multer.diskStorage({
  destination: uploadsDir,
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${uuidv4()}${ext}`);
  }
});
const upload = multer({
  storage,
  limits: { files: 8, fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    cb(null, ['image/jpeg','image/png','image/webp'].includes(file.mimetype));
  }
});

app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use('/uploads', express.static(uploadsDir, { maxAge: '7d' }));

const normalizePhone = (phone) => {
  let p = String(phone || '').replace(/\D/g, '');
  if (p.startsWith('0')) p = '254' + p.slice(1);
  if (p.startsWith('+')) p = p.slice(1);
  return p;
};
const publicUser = (u) => ({ id: u.id, name: u.name, phone: u.phone || '', email: u.email || '', role: u.role });
const signSession = (u) => jwt.sign({ sub: u.id, role: u.role }, JWT_SECRET, { expiresIn: '7d' });
const setSession = (res, u) => res.cookie('heybiage_session', signSession(u), {
  httpOnly: true, sameSite: 'lax', secure: process.env.COOKIE_SECURE === 'true', maxAge: 7 * 24 * 60 * 60 * 1000
});
const clearSession = (res) => res.clearCookie('heybiage_session', { httpOnly: true, sameSite: 'lax', secure: process.env.COOKIE_SECURE === 'true' });

function getAuthUser(req) {
  const token = req.cookies.heybiage_session;
  if (!token) return null;
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    return db.prepare('SELECT * FROM users WHERE id = ?').get(payload.sub) || null;
  } catch { return null; }
}
function requireAuth(req, res, next) {
  const user = getAuthUser(req);
  if (!user) return res.status(401).json({ error: 'Authentication required.' });
  req.user = user;
  next();
}
function requireAdmin(req, res, next) {
  const user = getAuthUser(req);
  if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Administrator access required.' });
  req.user = user;
  next();
}

function hashOtp(code) { return crypto.createHash('sha256').update(code).digest('hex'); }
function randomOtp() { return String(crypto.randomInt(100000, 1000000)); }

async function sendSms(phone, message) {
  const username = process.env.AFRICASTALKING_USERNAME;
  const apiKey = process.env.AFRICASTALKING_API_KEY;
  if (!username || !apiKey) {
    if (NODE_ENV !== 'production') {
      console.log(`[DEV OTP] ${phone}: ${message}`);
      return { simulated: true };
    }
    throw new Error('SMS provider is not configured.');
  }
  const body = new URLSearchParams({ username, to: phone, message });
  if (process.env.AFRICASTALKING_SENDER_ID) body.set('from', process.env.AFRICASTALKING_SENDER_ID);
  const r = await fetch('https://api.africastalking.com/version1/messaging', {
    method: 'POST', headers: { 'apiKey': apiKey, 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' }, body
  });
  if (!r.ok) throw new Error(`SMS provider returned ${r.status}`);
  return r.json();
}

function seedData() {
  const adminPhone = normalizePhone(process.env.ADMIN_PHONE || '254700000000');
  const admin = db.prepare('SELECT * FROM users WHERE phone = ?').get(adminPhone);
  if (!admin) {
    db.prepare('INSERT INTO users (id,name,phone,role) VALUES (?,?,?,?)').run(uuidv4(), process.env.ADMIN_NAME || 'HeyBiage Administrator', adminPhone, 'admin');
  } else if (admin.role !== 'admin') {
    db.prepare('UPDATE users SET role = ? WHERE id = ?').run('admin', admin.id);
  }

  const count = db.prepare('SELECT COUNT(*) c FROM listings').get().c;
  if (count > 0) return;
  const seller = db.prepare('SELECT * FROM users WHERE phone = ?').get('254700000002') || (() => {
    const u = { id: uuidv4(), name: 'Demo Seller', phone: '254700000002', role: 'user' };
    db.prepare('INSERT INTO users (id,name,phone,role) VALUES (?,?,?,?)').run(u.id,u.name,u.phone,u.role); return u;
  })();
  const seeds = [
    ['Mazda Demio 2015 — Red',750000,'Cars','Used — Good','Kisii','Demo marketplace listing.','🚗','approved'],
    ['Samsung 65" QLED Smart TV',95000,'Electronics','New','Nairobi','Demo marketplace listing.','💻','paid']
  ];
  const stmt = db.prepare('INSERT INTO listings (id,user_id,title,price,category,condition,location,description,icon,status,paid_at) VALUES (?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)');
  for (const s of seeds) stmt.run(uuidv4(), seller.id, ...s);
}
seedData();

function listingView(row) {
  const photos = db.prepare('SELECT file_path AS url, original_name AS name FROM listing_photos WHERE listing_id = ? ORDER BY sort_order').all(row.id)
    .map(p => ({ ...p, url: p.url.startsWith('http') ? p.url : `/uploads/${p.url}` }));
  const seller = db.prepare('SELECT name, phone, email FROM users WHERE id = ?').get(row.user_id);
  return { id: row.id, title: row.title, price: row.price, cat: row.category, cond: row.condition, loc: row.location, desc: row.description,
    icon: row.icon, status: row.status, photos, seller: seller?.name || 'Seller', sellerEmail: seller?.email || seller?.phone || '', phone: seller?.phone || '', createdAt: row.created_at, paidAt: row.paid_at, reviewedAt: row.reviewed_at };
}

app.get('/api/health', (_req,res) => res.json({ ok:true, service:'heybiage-api', time:new Date().toISOString() }));
app.get('/api/config', (_req,res) => res.json({ googleClientId: process.env.GOOGLE_CLIENT_ID || '' }));

app.post('/api/auth/request-otp', async (req,res) => {
  try {
    const phone = normalizePhone(req.body.phone);
    const name = String(req.body.name || '').trim();
    const mode = req.body.mode === 'signup' ? 'signup' : 'signin';
    if (!/^2547\d{8}$/.test(phone)) return res.status(400).json({ error:'Enter a valid Kenyan mobile number.' });
    let user = db.prepare('SELECT * FROM users WHERE phone = ?').get(phone);
    if (mode === 'signup' && user) return res.status(409).json({ error:'An account with that phone number already exists. Sign in instead.' });
    if (mode === 'signin' && !user) return res.status(404).json({ error:'No account exists for that phone number. Sign up first.' });
    if (mode === 'signup') {
      if (!name || name.length < 2) return res.status(400).json({ error:'Full name is required.' });
      if (!user) {
        user = { id:uuidv4(), name, phone, role:'user' };
        db.prepare('INSERT INTO users (id,name,phone,role) VALUES (?,?,?,?)').run(user.id,user.name,user.phone,user.role);
      }
    }
    const code = randomOtp();
    const expires = Date.now() + Number(process.env.OTP_TTL_SECONDS || 120) * 1000;
    db.prepare('UPDATE otp_codes SET used = 1 WHERE phone = ? AND used = 0').run(phone);
    db.prepare('INSERT INTO otp_codes (id,user_id,phone,code_hash,expires_at) VALUES (?,?,?,?,?)').run(uuidv4(), user?.id || null, phone, hashOtp(code), expires);
    await sendSms(phone, `Your HeyBiage verification code is ${code}. It expires in 2 minutes.`);
    res.json({ ok:true, phone:`+${phone}`, expiresAt:expires });
  } catch (e) { console.error(e); res.status(500).json({ error:'Could not send OTP.' }); }
});

app.post('/api/auth/verify-otp', (req,res) => {
  const phone = normalizePhone(req.body.phone);
  const code = String(req.body.code || '').trim();
  if (!/^\d{6}$/.test(code)) return res.status(400).json({ error:'Enter the 6-digit OTP.' });
  const otp = db.prepare('SELECT * FROM otp_codes WHERE phone = ? AND used = 0 ORDER BY created_at DESC LIMIT 1').get(phone);
  if (!otp || otp.expires_at < Date.now()) return res.status(400).json({ error:'OTP expired. Request a new code.' });
  if (otp.attempts >= 5) return res.status(429).json({ error:'Too many attempts. Request a new OTP.' });
  if (otp.code_hash !== hashOtp(code)) {
    db.prepare('UPDATE otp_codes SET attempts = attempts + 1 WHERE id = ?').run(otp.id);
    return res.status(400).json({ error:'Incorrect OTP.' });
  }
  db.prepare('UPDATE otp_codes SET used = 1 WHERE id = ?').run(otp.id);
  const user = db.prepare('SELECT * FROM users WHERE phone = ?').get(phone);
  if (!user) return res.status(404).json({ error:'Account not found.' });
  setSession(res,user);
  res.json({ ok:true, user:publicUser(user) });
});

app.post('/api/auth/logout', (req,res) => { clearSession(res); res.json({ ok:true }); });
app.get('/api/auth/me', (req,res) => { const u=getAuthUser(req); res.json({ user:u ? publicUser(u) : null }); });

app.post('/api/auth/google', async (req,res) => {
  try {
    if (!process.env.GOOGLE_CLIENT_ID) return res.status(503).json({ error:'Google sign-in is not configured on this server.' });
    const credential = String(req.body.credential || '');
    if (!credential) return res.status(400).json({ error:'Missing Google credential.' });
    const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);
    const ticket = await client.verifyIdToken({ idToken:credential, audience:process.env.GOOGLE_CLIENT_ID });
    const p = ticket.getPayload();
    if (!p?.sub || !p.email) return res.status(400).json({ error:'Invalid Google account.' });
    let user = db.prepare('SELECT * FROM users WHERE google_sub = ? OR email = ?').get(p.sub, p.email);
    if (!user) {
      user = { id:uuidv4(), name:p.name || p.email.split('@')[0], phone:null, email:p.email, google_sub:p.sub, role:'user' };
      db.prepare('INSERT INTO users (id,name,email,google_sub,role) VALUES (?,?,?,?,?)').run(user.id,user.name,user.email,user.google_sub,user.role);
    } else if (!user.google_sub) {
      db.prepare('UPDATE users SET google_sub = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?').run(p.sub,user.id);
      user = db.prepare('SELECT * FROM users WHERE id = ?').get(user.id);
    }
    setSession(res,user); res.json({ ok:true,user:publicUser(user) });
  } catch (e) { console.error(e); res.status(401).json({ error:'Google authentication failed.' }); }
});

app.get('/api/listings', (req,res) => {
  const q = String(req.query.q || '').trim();
  const category = String(req.query.category || '').trim();
  const sort = String(req.query.sort || 'newest');
  const params = [];
  let sql = `SELECT * FROM listings WHERE status = 'approved'`;
  if (q) { sql += ` AND (title LIKE ? OR location LIKE ? OR description LIKE ?)`; const like=`%${q}%`; params.push(like,like,like); }
  if (category && category !== 'all') { sql += ` AND lower(category) = lower(?)`; params.push(category); }
  sql += sort === 'price_asc' ? ' ORDER BY price ASC' : sort === 'price_desc' ? ' ORDER BY price DESC' : ' ORDER BY created_at DESC';
  const rows = db.prepare(sql).all(...params);
  res.json({ listings: rows.map(listingView) });
});

app.get('/api/listings/mine', requireAuth, (req,res) => {
  const rows = db.prepare('SELECT * FROM listings WHERE user_id = ? ORDER BY created_at DESC').all(req.user.id);
  res.json({ listings:rows.map(listingView) });
});

app.get('/api/listings/:id', (req,res) => {
  const row = db.prepare('SELECT * FROM listings WHERE id = ?').get(req.params.id);
  if (!row || (row.status !== 'approved' && getAuthUser(req)?.id !== row.user_id)) return res.status(404).json({ error:'Listing not found.' });
  res.json({ listing:listingView(row) });
});

app.post('/api/listings', requireAuth, upload.array('photos',8), (req,res) => {
  const title=String(req.body.title||'').trim();
  const price=Math.round(Number(req.body.price));
  const category=String(req.body.category||'Other').trim();
  const condition=String(req.body.condition||'New').trim();
  const location=String(req.body.location||'').trim();
  const description=String(req.body.description||'').trim();
  const icon=String(req.body.icon||'📦').slice(0,4);
  if (!title || !location || !Number.isFinite(price) || price <= 0) { for (const f of req.files||[]) fs.unlinkSync(f.path); return res.status(400).json({ error:'Title, valid price, and location are required.' }); }
  if (!req.files?.length) return res.status(400).json({ error:'At least one photo is required.' });
  const id=uuidv4();
  const tx=db.transaction(()=>{
    db.prepare('INSERT INTO listings (id,user_id,title,price,category,condition,location,description,icon,status) VALUES (?,?,?,?,?,?,?,?,?,?)').run(id,req.user.id,title,price,category,condition,location,description,icon,'pending_payment');
    const p=db.prepare('INSERT INTO listing_photos (id,listing_id,file_path,original_name,sort_order) VALUES (?,?,?,?,?)');
    req.files.forEach((f,i)=>p.run(uuidv4(),id,f.filename,f.originalname,i));
  });
  try { tx(); } catch(e) { for (const f of req.files||[]) { try{fs.unlinkSync(f.path)}catch{} } throw e; }
  res.status(201).json({ listing:listingView(db.prepare('SELECT * FROM listings WHERE id=?').get(id)) });
});

app.delete('/api/listings/:id', requireAuth, (req,res) => {
  const row=db.prepare('SELECT * FROM listings WHERE id=? AND user_id=?').get(req.params.id,req.user.id);
  if (!row) return res.status(404).json({ error:'Listing not found.' });
  const photos=db.prepare('SELECT file_path FROM listing_photos WHERE listing_id=?').all(row.id);
  db.prepare('DELETE FROM listings WHERE id=?').run(row.id);
  for (const p of photos) { try{fs.unlinkSync(path.join(uploadsDir,p.file_path))}catch{} }
  res.json({ok:true});
});

async function mpesaToken() {
  const base=process.env.MPESA_ENV==='production' ? 'https://api.safaricom.co.ke' : 'https://sandbox.safaricom.co.ke';
  const auth=Buffer.from(`${process.env.MPESA_CONSUMER_KEY}:${process.env.MPESA_CONSUMER_SECRET}`).toString('base64');
  const r=await fetch(`${base}/oauth/v1/generate?grant_type=client_credentials`,{headers:{Authorization:`Basic ${auth}`}});
  if(!r.ok) throw new Error(`Daraja auth failed (${r.status})`);
  return (await r.json()).access_token;
}
function mpesaConfigured(){ return Boolean(process.env.MPESA_CONSUMER_KEY && process.env.MPESA_CONSUMER_SECRET && process.env.MPESA_SHORTCODE && process.env.MPESA_PASSKEY && process.env.MPESA_CALLBACK_URL); }

app.post('/api/payments/mpesa/stk-push', requireAuth, async (req,res) => {
  try {
    if (!mpesaConfigured()) return res.status(503).json({ error:'M-Pesa is not configured on the server yet.' });
    const listing=db.prepare('SELECT * FROM listings WHERE id=? AND user_id=?').get(req.body.listingId,req.user.id);
    if (!listing) return res.status(404).json({ error:'Listing not found.' });
    if (listing.status !== 'pending_payment') return res.status(409).json({ error:'This listing is not awaiting payment.' });
    const phone=normalizePhone(req.body.phone || req.user.phone);
    if (!/^2547\d{8}$/.test(phone)) return res.status(400).json({ error:'Enter a valid M-Pesa phone number.' });
    const amount=Math.max(1,Math.ceil(listing.price*0.05));
    const paymentId=uuidv4();
    db.prepare('INSERT INTO payments (id,listing_id,user_id,amount,status,phone) VALUES (?,?,?,?,?,?)').run(paymentId,listing.id,req.user.id,amount,'initiated',phone);
    const token=await mpesaToken();
    const base=process.env.MPESA_ENV==='production' ? 'https://api.safaricom.co.ke' : 'https://sandbox.safaricom.co.ke';
    const now=new Date();
    const timestamp=now.toISOString().replace(/[-:TZ.]/g,'').slice(0,14);
    const password=Buffer.from(`${process.env.MPESA_SHORTCODE}${process.env.MPESA_PASSKEY}${timestamp}`).toString('base64');
    const payload={BusinessShortCode:process.env.MPESA_SHORTCODE,Password:password,Timestamp:timestamp,TransactionType:process.env.MPESA_TRANSACTION_TYPE||'CustomerBuyGoodsOnline',Amount:amount,PartyA:phone,PartyB:(process.env.MPESA_PARTY_B || process.env.MPESA_SHORTCODE),PhoneNumber:phone,CallBackURL:process.env.MPESA_CALLBACK_URL,AccountReference:`HEY-${listing.id.slice(0,8)}`,TransactionDesc:`HeyBiage listing fee`};
    const r=await fetch(`${base}/mpesa/stkpush/v1/processrequest`,{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify(payload)});
    const data=await r.json();
    if (!r.ok || data.ResponseCode !== '0') { db.prepare('UPDATE payments SET status=?,result_description=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run('failed',data.ResponseDescription||'STK push failed',paymentId); return res.status(502).json({error:data.ResponseDescription||'M-Pesa rejected the request.'}); }
    db.prepare('UPDATE payments SET status=?,merchant_request_id=?,checkout_request_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run('pending',data.MerchantRequestID,data.CheckoutRequestID,paymentId);
    res.json({ok:true,paymentId,checkoutRequestId:data.CheckoutRequestID,amount});
  } catch(e){ console.error(e); res.status(502).json({error:'Could not start the M-Pesa payment.'}); }
});

app.post('/api/payments/confirmation', (req,res) => {
  try {
    const body=req.body || {};
    const callback=body.Body?.stkCallback;
    if (!callback) return res.json({ResultCode:0,ResultDesc:'Accepted'});
    const payment=db.prepare('SELECT * FROM payments WHERE checkout_request_id=?').get(callback.CheckoutRequestID);
    if (!payment) return res.json({ResultCode:0,ResultDesc:'Accepted'});
    const items=callback.CallbackMetadata?.Item || [];
    const get=(name)=>items.find(i=>i.Name===name)?.Value;
    const receipt=get('MpesaReceiptNumber');
    const resultCode=String(callback.ResultCode ?? '');
    if (resultCode==='0') {
      const tx=db.transaction(()=>{
        db.prepare('UPDATE payments SET status=?,receipt=?,result_code=?,result_description=?,raw_callback=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run('paid',receipt||null,resultCode,callback.ResultDesc||'',JSON.stringify(body),payment.id);
        db.prepare('UPDATE listings SET status=?,paid_at=CURRENT_TIMESTAMP WHERE id=? AND status=?').run('paid',payment.listing_id,'pending_payment');
      }); tx();
    } else {
      db.prepare('UPDATE payments SET status=?,result_code=?,result_description=?,raw_callback=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run('failed',resultCode,callback.ResultDesc||'',JSON.stringify(body),payment.id);
    }
    res.json({ResultCode:0,ResultDesc:'Accepted'});
  } catch(e){ console.error(e); res.json({ResultCode:0,ResultDesc:'Accepted'}); }
});

app.get('/api/payments/:id', requireAuth, (req,res) => {
  const p=db.prepare('SELECT * FROM payments WHERE id=? AND user_id=?').get(req.params.id,req.user.id);
  if (!p) return res.status(404).json({error:'Payment not found.'});
  res.json({payment:{id:p.id,status:p.status,amount:p.amount,receipt:p.receipt,resultDescription:p.result_description}});
});

app.get('/api/admin/listings', requireAdmin, (req,res) => {
  const status=['pending_payment','paid','approved','rejected'].includes(req.query.status) ? req.query.status : 'paid';
  const rows=db.prepare('SELECT * FROM listings WHERE status=? ORDER BY created_at DESC').all(status);
  res.json({listings:rows.map(listingView)});
});
app.get('/api/admin/stats', requireAdmin, (_req,res) => {
  const count=(s)=>db.prepare('SELECT COUNT(*) c FROM listings WHERE status=?').get(s).c;
  const revenue=db.prepare(`SELECT COALESCE(SUM(amount),0) total FROM payments WHERE status='paid'`).get().total;
  res.json({revenue,collected:count('paid')+count('approved'),pendingPayment:count('pending_payment'),paid:count('paid'),approved:count('approved'),rejected:count('rejected')});
});
app.post('/api/admin/login', (req,res) => {
  const pin=String(req.body.pin||'');
  const expected=String(process.env.ADMIN_PIN||'');
  const a=Buffer.from(pin); const b=Buffer.from(expected);
  if (!expected || a.length !== b.length || !crypto.timingSafeEqual(a,b)) return res.status(401).json({error:'Incorrect admin PIN.'});
  const user=db.prepare('SELECT * FROM users WHERE role="admin" ORDER BY created_at LIMIT 1').get();
  if (!user) return res.status(500).json({error:'Admin account is not initialized.'});
  setSession(res,user); res.json({ok:true,user:publicUser(user)});
});
app.post('/api/admin/listings/:id/action', requireAdmin, (req,res) => {
  const action=String(req.body.action||'');
  if (!['approved','rejected'].includes(action)) return res.status(400).json({error:'Invalid admin action.'});
  const row=db.prepare('SELECT * FROM listings WHERE id=?').get(req.params.id);
  if (!row) return res.status(404).json({error:'Listing not found.'});
  db.prepare('UPDATE listings SET status=?, reviewed_at=CURRENT_TIMESTAMP WHERE id=?').run(action,row.id);
  res.json({ok:true,listing:listingView(db.prepare('SELECT * FROM listings WHERE id=?').get(row.id))});
});

app.use(express.static(path.join(__dirname,'public')));
app.use((req,res,next) => {
  if (req.path.startsWith('/api/') || req.path.startsWith('/uploads/')) return next();
  if (req.method === 'GET' && !path.extname(req.path)) return res.sendFile(path.join(__dirname,'public','index.html'));
  next();
});

app.use((err,req,res,_next)=>{
  console.error(err);
  if (err instanceof multer.MulterError) return res.status(400).json({error:`Upload error: ${err.message}`});
  res.status(500).json({error:'Internal server error.'});
});

app.listen(PORT,()=>console.log(`HeyBiage server running at http://localhost:${PORT}`));
