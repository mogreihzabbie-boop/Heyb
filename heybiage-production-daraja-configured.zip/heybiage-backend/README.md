# HeyBiage full-stack backend

This package turns the original HeyBiage HTML marketplace into a client/server application.

## What is now server-backed

- Phone OTP registration and login
- HttpOnly cookie sessions
- Server-side admin authorization
- SQLite database for users, listings, photos and payments
- Real listing creation and image uploads
- Public approved listings API
- Seller's own listings API
- Admin listing review/approval/rejection API
- M-Pesa Daraja STK Push integration and callback processing
- Google Identity token verification endpoint
- Optional Africa's Talking SMS delivery for OTPs
- Server-side validation of listing/payment state

## Run locally

1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Set a strong `JWT_SECRET` and an `ADMIN_PIN`.
4. For development, you can leave SMS and M-Pesa credentials empty. OTPs will be printed to the server console, while M-Pesa will report that it is not configured.
5. Install dependencies:

```bash
npm install
```

6. Start:

```bash
npm start
```

7. Open `http://localhost:3000`.

## M-Pesa setup

Set the Daraja consumer key/secret, Lipa na M-Pesa Online business shortcode, passkey, Buy Goods till (`MPESA_PARTY_B`) and a publicly reachable HTTPS callback URL in `.env`. For Buy Goods, `MPESA_SHORTCODE` is the Lipa na M-Pesa Online business shortcode used to generate the password; `MPESA_PARTY_B` is the actual till number credited. Confirm the correct values for your account with Safaricom before live transactions.

For local testing, expose the server with a tunnel such as ngrok or LocalTunnel and set `MPESA_CALLBACK_URL` to:

`https://YOUR_PUBLIC_DOMAIN/api/payments/confirmation`

The callback endpoint must be reachable by Safaricom. The application does not mark a listing as paid merely because the browser says payment was made; it waits for the Daraja callback.

## SMS OTP setup

Set:

- `AFRICASTALKING_USERNAME`
- `AFRICASTALKING_API_KEY`
- optional `AFRICASTALKING_SENDER_ID`

Without these in development, the generated OTP is printed in the server log. Do not use that fallback in production.

## Google sign-in

Set `GOOGLE_CLIENT_ID` to the OAuth web client ID. The frontend will use Google Identity Services and send the ID token to `/api/auth/google`, where it is verified server-side.

## Production checklist

- Use PostgreSQL or another managed database if you expect substantial traffic.
- Put the app behind HTTPS.
- Set `COOKIE_SECURE=true`.
- Generate a strong random `JWT_SECRET`.
- Configure real SMS delivery.
- Configure Daraja production credentials and callback URL.
- Restrict/monitor upload sizes and storage.
- Back up the database and uploads.
- Configure Safaricom callback IP controls according to the current Daraja requirements.
- Add rate limiting/WAF protections before public launch.

## Important

The generated code is a working backend implementation/scaffold, but external services cannot be activated without your own provider credentials and a publicly reachable deployment. Never put Daraja, SMS, Google client secrets, admin credentials or JWT secrets in the frontend.

### Persistent storage (production)

The backend stores SQLite and uploaded photos under `DATA_DIR`. For a host with a persistent disk mounted at `/var/data`, set `DATA_DIR=/var/data`. Keep that directory on persistent storage; otherwise the database and uploaded photos may be lost on redeploy/restart.


## Production deployment (Daraja / Buy Goods)

- Use `.env.production.example` as a checklist for your hosting provider's environment-variable dashboard; do not commit a populated `.env` file.
- The template pre-fills the Daraja app's displayed shortcode `6855865`. Confirm with Safaricom that this is the `BusinessShortCode` for your approved Lipa Na M-Pesa Online production integration.
- Set `MPESA_PARTY_B` to your registered Buy Goods Till number if Safaricom's account-specific integration instructions require it. Do not assume the Till and Lipa Na M-Pesa Online shortcode are interchangeable.
- The callback URL must be publicly reachable over HTTPS and must match the callback route in this backend: `/api/payments/confirmation`.
- On Render, attach persistent storage at `/var/data` and set `DATA_DIR=/var/data` so the SQLite database and uploads survive redeploys.
- Credentials previously exposed in a screenshot must be rotated before production use. Enter only the replacement values directly in the hosting dashboard.
